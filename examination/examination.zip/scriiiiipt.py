k=["finetuned_DenseNet_XR_FINGER.keras","finetuned_ResNet_XR_FINGER.keras", "finetuned_VGG_XR_FINGER.keras" ]

print(k+"hello")